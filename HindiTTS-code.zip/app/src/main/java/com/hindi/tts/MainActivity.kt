package com.hindi.tts

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import java.io.File
import java.io.OutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity(), TextToSpeech.OnInitListener {

    private var tts: TextToSpeech? = null
    private var triedDefaultEngine = false
    private var voices: List<Voice> = emptyList()

    private lateinit var text: EditText
    private lateinit var voiceSpinner: Spinner
    private lateinit var showAll: CheckBox
    private lateinit var speed: SeekBar
    private lateinit var pitch: SeekBar
    private lateinit var status: TextView
    private lateinit var saveBtn: Button

    // Saving state
    @Volatile private var saveParts: List<File> = emptyList()
    @Volatile private var savedCount = 0
    @Volatile private var saveTarget: Uri? = null
    @Volatile private var saving = false

    private val saveLauncher =
        registerForActivityResult(ActivityResultContracts.CreateDocument("audio/wav")) { uri ->
            if (uri != null) startSave(uri)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        text = findViewById(R.id.text)
        voiceSpinner = findViewById(R.id.voice)
        showAll = findViewById(R.id.showAll)
        speed = findViewById(R.id.speed)
        pitch = findViewById(R.id.pitch)
        status = findViewById(R.id.status)
        saveBtn = findViewById(R.id.save)

        val speedLabel: TextView = findViewById(R.id.speedLabel)
        val pitchLabel: TextView = findViewById(R.id.pitchLabel)
        speed.setOnSeekBarChangeListener(simpleSeek { speedLabel.text = "Speed: %.1fx".format(rate()) })
        pitch.setOnSeekBarChangeListener(simpleSeek { pitchLabel.text = "Pitch: %.1f".format(pitchValue()) })

        showAll.setOnCheckedChangeListener { _, _ -> loadVoices() }
        findViewById<Button>(R.id.play).setOnClickListener { play() }
        findViewById<Button>(R.id.stop).setOnClickListener {
            tts?.stop()
            if (saving) finishSave("Stopped.")
            else status.text = "Stopped."
        }
        saveBtn.setOnClickListener {
            if (text.text.toString().isBlank()) { toast("Type some text first."); return@setOnClickListener }
            val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
            saveLauncher.launch("hindi_tts_$stamp.wav")
        }
        findViewById<Button>(R.id.install).setOnClickListener {
            try {
                startActivity(Intent(TextToSpeech.Engine.ACTION_INSTALL_TTS_DATA))
            } catch (e: Exception) {
                toast("Open Settings → Text-to-speech → Google → Install voice data → Hindi")
            }
        }

        // Prefer Google's speech engine (has several Hindi voices)
        tts = TextToSpeech(this, this, "com.google.android.tts")
    }

    override fun onInit(result: Int) {
        if (result != TextToSpeech.SUCCESS) {
            if (!triedDefaultEngine) {
                triedDefaultEngine = true
                tts?.shutdown()
                tts = TextToSpeech(this, this)
            } else {
                runOnUiThread { status.text = "No speech engine found. Install \"Speech Services by Google\" from Play Store." }
            }
            return
        }
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) {
                if (utteranceId != null && utteranceId.startsWith("save")) onPartSaved()
                else if (utteranceId == "play_last") runOnUiThread { status.text = "Done." }
            }
            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) {
                if (utteranceId != null && utteranceId.startsWith("save")) runOnUiThread { finishSave("Could not save. Try another voice.") }
            }
            override fun onError(utteranceId: String?, errorCode: Int) {
                if (utteranceId != null && utteranceId.startsWith("save")) {
                    runOnUiThread {
                        finishSave(
                            if (errorCode == TextToSpeech.ERROR_NOT_INSTALLED_YET || errorCode == TextToSpeech.ERROR_NETWORK || errorCode == TextToSpeech.ERROR_NETWORK_TIMEOUT)
                                "This voice is not downloaded. Tap \"Download more voices\", or pick an offline voice."
                            else "Could not save (error $errorCode). Try another voice."
                        )
                    }
                }
            }
        })
        runOnUiThread { loadVoices() }
    }

    private fun loadVoices() {
        val engine = tts ?: return
        val all = try { engine.voices?.toList() ?: emptyList() } catch (e: Exception) { emptyList() }
        val list = all.filter { showAll.isChecked || it.locale.language == "hi" }
            .sortedWith(compareBy<Voice>({ !isOffline(it) }, { it.locale.toString() }, { it.name }))
        voices = list

        val labels = list.mapIndexed { i, v ->
            val where = if (isOffline(v)) "offline" else "online"
            val lang = if (showAll.isChecked) "${v.locale.displayName} · " else ""
            "${lang}Voice ${i + 1} · $where  (${v.name})"
        }
        voiceSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, labels)
        findViewById<TextView>(R.id.voiceLabel).text = "Voice (${list.size} found)"

        status.text = when {
            list.isEmpty() && !showAll.isChecked ->
                "No Hindi voices yet. Tap \"Download more voices\" → Hindi, then reopen the app."
            else -> "Ready. Play each voice to hear which are male or female."
        }
    }

    private fun isOffline(v: Voice): Boolean {
        val f = v.features ?: emptySet()
        return !v.isNetworkConnectionRequired && !f.contains(TextToSpeech.Engine.KEY_FEATURE_NOT_INSTALLED)
    }

    private fun rate() = (speed.progress + 5) / 10f
    private fun pitchValue() = (pitch.progress + 5) / 10f

    private fun applySettings(): Boolean {
        val engine = tts ?: return false
        val v = voices.getOrNull(voiceSpinner.selectedItemPosition)
        if (v != null) engine.setVoice(v) else engine.setLanguage(Locale("hi", "IN"))
        engine.setSpeechRate(rate())
        engine.setPitch(pitchValue())
        return true
    }

    private fun play() {
        val t = text.text.toString().trim()
        if (t.isEmpty()) { toast("Type some text first."); return }
        if (saving) { toast("Please wait, still saving."); return }
        if (!applySettings()) return
        val chunks = splitText(t)
        chunks.forEachIndexed { i, c ->
            val id = if (i == chunks.lastIndex) "play_last" else "play_$i"
            tts?.speak(c, if (i == 0) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD, null, id)
        }
        status.text = "Speaking…"
    }

    // ---------- Saving ----------

    private fun startSave(uri: Uri) {
        val t = text.text.toString().trim()
        if (t.isEmpty() || !applySettings()) return
        tts?.stop()
        val chunks = splitText(t)
        cacheDir.listFiles()?.filter { it.name.startsWith("part_") }?.forEach { it.delete() }
        saveParts = chunks.indices.map { File(cacheDir, "part_$it.wav") }
        savedCount = 0
        saveTarget = uri
        saving = true
        saveBtn.isEnabled = false
        status.text = "Saving… 0/${chunks.size}"
        chunks.forEachIndexed { i, c ->
            tts?.synthesizeToFile(c, Bundle(), saveParts[i], "save_$i")
        }
    }

    private fun onPartSaved() {
        if (!saving) return
        savedCount++
        val total = saveParts.size
        runOnUiThread { status.text = "Saving… $savedCount/$total" }
        if (savedCount < total) return
        val target = saveTarget ?: return
        Thread {
            val msg = try {
                contentResolver.openOutputStream(target)?.use { mergeWavs(saveParts, it) }
                    ?: throw IllegalStateException("Cannot open file")
                "Saved! Find it in the folder you picked (usually Downloads)."
            } catch (e: Exception) {
                "Save failed: ${e.message}"
            }
            runOnUiThread { finishSave(msg) }
        }.start()
    }

    private fun finishSave(msg: String) {
        saving = false
        saveBtn.isEnabled = true
        status.text = msg
        saveParts.forEach { it.delete() }
    }

    /** Joins several WAV files (same format) into one WAV. */
    private fun mergeWavs(files: List<File>, out: OutputStream) {
        data class Part(val fmt: ByteArray, val bytes: ByteArray, val dataStart: Int, val dataLen: Int)

        val parts = files.map { f ->
            val b = f.readBytes()
            if (b.size < 12 || String(b, 0, 4, Charsets.US_ASCII) != "RIFF") throw IllegalStateException("Bad audio part")
            var pos = 12
            var fmt: ByteArray? = null
            var dStart = -1
            var dLen = 0
            while (pos + 8 <= b.size) {
                val id = String(b, pos, 4, Charsets.US_ASCII)
                var size = ByteBuffer.wrap(b, pos + 4, 4).order(ByteOrder.LITTLE_ENDIAN).int
                val body = pos + 8
                if (size < 0 || body + size > b.size) size = b.size - body
                if (id == "fmt ") fmt = b.copyOfRange(body, body + size)
                if (id == "data") {
                    dStart = body
                    dLen = if (size == 0) b.size - body else size
                    break
                }
                pos = body + size + (size and 1)
            }
            if (fmt == null || dStart < 0) throw IllegalStateException("Bad audio part")
            Part(fmt, b, dStart, dLen)
        }

        val fmt = parts.first().fmt
        val dataTotal = parts.sumOf { it.dataLen.toLong() }
        val header = ByteBuffer.allocate(12 + 8 + fmt.size + 8).order(ByteOrder.LITTLE_ENDIAN)
        header.put("RIFF".toByteArray(Charsets.US_ASCII))
        header.putInt((4 + 8 + fmt.size + 8 + dataTotal).toInt())
        header.put("WAVE".toByteArray(Charsets.US_ASCII))
        header.put("fmt ".toByteArray(Charsets.US_ASCII))
        header.putInt(fmt.size)
        header.put(fmt)
        header.put("data".toByteArray(Charsets.US_ASCII))
        header.putInt(dataTotal.toInt())
        out.write(header.array())
        parts.forEach { out.write(it.bytes, it.dataStart, it.dataLen) }
        out.flush()
    }

    /** Splits long text into pieces the speech engine accepts, at sentence ends. */
    private fun splitText(t: String): List<String> {
        val max = minOf(TextToSpeech.getMaxSpeechInputLength(), 3000)
        val sentences = Regex("(?<=[।.!?\\n])").split(t).filter { it.isNotBlank() }
        val out = mutableListOf<String>()
        val cur = StringBuilder()
        fun flush() { if (cur.isNotBlank()) out.add(cur.toString().trim()); cur.clear() }
        for (s in sentences) {
            if (s.length > max) {
                flush()
                var rest = s
                while (rest.length > max) {
                    var cut = rest.lastIndexOf(' ', max)
                    if (cut <= 0) cut = max
                    out.add(rest.substring(0, cut).trim())
                    rest = rest.substring(cut)
                }
                cur.append(rest)
            } else {
                if (cur.length + s.length > max) flush()
                cur.append(s)
            }
        }
        flush()
        return out.ifEmpty { listOf(t) }
    }

    private fun simpleSeek(onChange: () -> Unit) = object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) = onChange()
        override fun onStartTrackingTouch(seekBar: SeekBar?) {}
        override fun onStopTrackingTouch(seekBar: SeekBar?) {}
    }

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_LONG).show()

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}
