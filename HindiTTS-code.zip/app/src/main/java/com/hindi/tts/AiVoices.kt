package com.hindi.tts

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.net.Uri
import com.k2fsa.sherpa.onnx.OfflineTts
import com.k2fsa.sherpa.onnx.OfflineTtsConfig
import com.k2fsa.sherpa.onnx.OfflineTtsKokoroModelConfig
import com.k2fsa.sherpa.onnx.OfflineTtsModelConfig
import com.k2fsa.sherpa.onnx.OfflineTtsVitsModelConfig
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream
import org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream
import java.io.BufferedInputStream
import java.io.File
import java.io.OutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.max
import kotlin.math.min

/** A voice package unpacked into the app's storage (Piper/VITS or Kokoro). */
class VoicePack(val dir: File) {
    private fun find(pred: (File) -> Boolean) = dir.walkTopDown().firstOrNull(pred)
    val model: File? by lazy { find { it.isFile && it.name.endsWith(".onnx") } }
    val tokens: File? by lazy { find { it.isFile && it.name == "tokens.txt" } }
    val voicesBin: File? by lazy { find { it.isFile && it.name == "voices.bin" } }
    val espeakData: File? by lazy { find { it.isDirectory && it.name == "espeak-ng-data" } }
    val lexicon: File? by lazy { find { it.isFile && it.name == "lexicon.txt" } }
    val isKokoro get() = voicesBin != null
    val isValid get() = model != null && tokens != null
}

/** One selectable AI voice: a pack plus a speaker inside it. */
data class AiVoice(val dir: File, val sid: Int, val label: String, val isKokoro: Boolean) {
    val name get() = label
}

/** Hindi speakers inside kokoro-multi-lang-v1_0 (speaker id -> name). */
private val KOKORO_V10_HINDI = listOf(
    31 to "Alpha (female) · Kokoro",
    32 to "Beta (female) · Kokoro",
    33 to "Omega (male) · Kokoro",
    34 to "Psi (male) · Kokoro",
)

private fun piperLabel(dirName: String): String {
    val n = dirName.removePrefix("vits-piper-").removePrefix("vits-")
    return when {
        "priyamvada" in n -> "Priyamvada (female) · Piper"
        "rohan" in n -> "Rohan (male) · Piper"
        "pratham" in n -> "Pratham (male) · Piper"
        else -> "$n · Piper"
    }
}

/** Manages AI voices: importing from Downloads, loading, speaking and saving. */
class AiVoices(private val context: Context) {

    private val root = File(context.filesDir, "voices").apply { mkdirs() }
    private var loadedDir: File? = null
    private var engine: OfflineTts? = null
    @Volatile var stopRequested = false
    @Volatile private var track: AudioTrack? = null

    fun list(): List<AiVoice> {
        val out = ArrayList<AiVoice>()
        for (d in (root.listFiles() ?: emptyArray()).filter { it.isDirectory && !it.name.startsWith(".") }.sortedBy { it.name }) {
            val pack = VoicePack(d)
            if (!pack.isValid) continue
            if (pack.isKokoro) {
                if (d.name.contains("v1_0")) {
                    KOKORO_V10_HINDI.forEach { (sid, label) -> out.add(AiVoice(d, sid, label, true)) }
                }
            } else {
                out.add(AiVoice(d, 0, piperLabel(d.name), false))
            }
        }
        return out
    }

    /** Kokoro packages that are not v1.0 have different speaker numbers, so we can't use them. */
    fun unsupportedPacks(): List<String> =
        (root.listFiles() ?: emptyArray()).filter { it.isDirectory && !it.name.startsWith(".") }
            .filter { VoicePack(it).isKokoro && !it.name.contains("v1_0") }.map { it.name }

    /** Unpacks a sherpa-onnx voice package (.tar.bz2) picked by the user. Returns its folder. */
    fun import(uri: Uri, onProgress: (String) -> Unit): File {
        val tmp = File(root, ".importing").apply { deleteRecursively(); mkdirs() }
        var files = 0
        context.contentResolver.openInputStream(uri)!!.use { raw ->
            val tar = try {
                TarArchiveInputStream(BZip2CompressorInputStream(BufferedInputStream(raw, 1 shl 16)))
            } catch (e: Exception) {
                throw IllegalArgumentException("This is not a voice package. Pick the file ending in .tar.bz2")
            }
            tar.use {
                val base = tmp.canonicalPath + File.separator
                while (true) {
                    val entry = it.nextEntry ?: break
                    val out = File(tmp, entry.name)
                    if (!out.canonicalPath.startsWith(base)) continue // skip unsafe paths
                    if (entry.isDirectory) { out.mkdirs(); continue }
                    out.parentFile?.mkdirs()
                    out.outputStream().use { o -> it.copyTo(o, 1 shl 16) }
                    files++
                    if (files % 25 == 0) onProgress("Unpacking voice… $files files")
                }
            }
        }
        // The package normally holds one top folder, e.g. vits-piper-hi_IN-rohan-medium/
        val top = tmp.listFiles()?.singleOrNull { it.isDirectory } ?: tmp
        val probe = VoicePack(top)
        if (!probe.isValid) {
            tmp.deleteRecursively()
            throw IllegalArgumentException("No voice found inside this file. Use a vits-piper-….tar.bz2 voice package.")
        }
        val name = if (top == tmp) "voice-${System.currentTimeMillis()}" else top.name
        val dest = File(root, name)
        if (dest.exists()) dest.deleteRecursively()
        if (!top.renameTo(dest)) { top.copyRecursively(dest, true) }
        tmp.deleteRecursively()
        return dest
    }

    /** Removes the whole voice package (all speakers in it). */
    fun delete(v: AiVoice) {
        if (loadedDir == v.dir) { engine?.release(); engine = null; loadedDir = null }
        v.dir.deleteRecursively()
    }

    private fun engineFor(v: AiVoice): OfflineTts {
        if (loadedDir == v.dir && engine != null) return engine!!
        engine?.release()
        engine = null
        val pack = VoicePack(v.dir)
        val threads = max(1, min(4, Runtime.getRuntime().availableProcessors() / 2))
        val modelConfig = if (pack.isKokoro) {
            OfflineTtsModelConfig(
                kokoro = OfflineTtsKokoroModelConfig(
                    model = pack.model!!.absolutePath,
                    voices = pack.voicesBin!!.absolutePath,
                    tokens = pack.tokens!!.absolutePath,
                    dataDir = pack.espeakData?.absolutePath ?: "",
                    lang = "hi",
                ),
                numThreads = threads, debug = false, provider = "cpu",
            )
        } else {
            OfflineTtsModelConfig(
                vits = OfflineTtsVitsModelConfig(
                    model = pack.model!!.absolutePath,
                    tokens = pack.tokens!!.absolutePath,
                    dataDir = pack.espeakData?.absolutePath ?: "",
                    lexicon = pack.lexicon?.absolutePath ?: "",
                ),
                numThreads = threads, debug = false, provider = "cpu",
            )
        }
        engine = OfflineTts(assetManager = null, config = OfflineTtsConfig(model = modelConfig))
        loadedDir = v.dir
        return engine!!
    }

    /**
     * Makes audio for one piece with the wanted speed and pitch.
     * Pitch is changed by resampling; to keep the speed right we ask the model
     * for speech that is slower/faster by the same factor first.
     */
    private fun render(tts: OfflineTts, v: AiVoice, text: String, speed: Float, pitch: Float): FloatArray {
        val p = pitch.coerceIn(0.7f, 1.4f)
        val samples = tts.generate(text, sid = v.sid, speed = speed / p).samples
        if (kotlin.math.abs(p - 1f) < 0.02f) return samples
        val n = (samples.size / p).toInt()
        val out = FloatArray(n)
        for (i in 0 until n) {
            val x = i * p
            val j = x.toInt()
            val f = x - j
            val a = samples.getOrElse(j) { 0f }
            val b = samples.getOrElse(j + 1) { a }
            out[i] = a + (b - a) * f
        }
        return out
    }

    /** Speaks text piece by piece. Runs on a background thread. */
    fun speak(v: AiVoice, pieces: List<String>, speed: Float, pitch: Float, onStatus: (String) -> Unit) {
        stopRequested = false
        onStatus("Loading voice…")
        val tts = engineFor(v)
        val rate = tts.sampleRate()
        val minBuf = AudioTrack.getMinBufferSize(rate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_FLOAT)
        val t = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_FLOAT)
                    .setSampleRate(rate)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setBufferSizeInBytes(max(minBuf, rate * 4))
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()
        track = t
        try {
            t.play()
            for ((i, p) in pieces.withIndex()) {
                if (stopRequested) break
                onStatus(if (pieces.size > 1) "Speaking… ${i + 1}/${pieces.size}" else "Speaking…")
                val audio = render(tts, v, p, speed, pitch)
                if (stopRequested) break
                t.write(audio, 0, audio.size, AudioTrack.WRITE_BLOCKING)
            }
            if (!stopRequested) {
                // let the last bit finish playing
                Thread.sleep(300)
            }
        } finally {
            try { t.stop() } catch (_: Exception) {}
            t.release()
            track = null
        }
        onStatus(if (stopRequested) "Stopped." else "Done.")
    }

    fun stop() {
        stopRequested = true
        try { track?.pause(); track?.flush() } catch (_: Exception) {}
    }

    /** Generates the whole text and writes a 16-bit WAV file. Runs on a background thread. */
    fun save(v: AiVoice, pieces: List<String>, speed: Float, pitch: Float, out: OutputStream, onStatus: (String) -> Unit) {
        stopRequested = false
        onStatus("Loading voice…")
        val tts = engineFor(v)
        val rate = tts.sampleRate()
        val parts = ArrayList<ShortArray>()
        for ((i, p) in pieces.withIndex()) {
            if (stopRequested) throw InterruptedException("Stopped.")
            onStatus("Saving… ${i + 1}/${pieces.size}")
            val s = render(tts, v, p, speed, pitch)
            parts.add(ShortArray(s.size) { k -> (s[k].coerceIn(-1f, 1f) * 32767f).toInt().toShort() })
        }
        val total = parts.sumOf { it.size } * 2
        val h = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
        h.put("RIFF".toByteArray()); h.putInt(36 + total); h.put("WAVE".toByteArray())
        h.put("fmt ".toByteArray()); h.putInt(16); h.putShort(1); h.putShort(1)
        h.putInt(rate); h.putInt(rate * 2); h.putShort(2); h.putShort(16)
        h.put("data".toByteArray()); h.putInt(total)
        out.write(h.array())
        for (p in parts) {
            val b = ByteBuffer.allocate(p.size * 2).order(ByteOrder.LITTLE_ENDIAN)
            b.asShortBuffer().put(p)
            out.write(b.array())
        }
        out.flush()
    }
}
