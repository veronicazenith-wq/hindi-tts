#!/usr/bin/env bash
# Fetches the sherpa-onnx speech engine (for AI voices) before building.
set -euo pipefail
V=1.13.8
curl -fsSL -o /tmp/sherpa.aar "https://github.com/k2-fsa/sherpa-onnx/releases/download/v$V/sherpa-onnx-$V.aar"
rm -rf /tmp/aar && mkdir -p /tmp/aar && unzip -q -o /tmp/sherpa.aar -d /tmp/aar
echo "AAR native libs:"; find /tmp/aar/jni -name '*.so'
for abi in arm64-v8a armeabi-v7a; do
  mkdir -p "app/src/main/jniLibs/$abi"
  cp /tmp/aar/jni/$abi/*.so "app/src/main/jniLibs/$abi/"
done
mkdir -p app/src/main/java/com/k2fsa/sherpa/onnx
curl -fsSL -o app/src/main/java/com/k2fsa/sherpa/onnx/Tts.kt \
  "https://raw.githubusercontent.com/k2-fsa/sherpa-onnx/v$V/sherpa-onnx/kotlin-api/Tts.kt"
