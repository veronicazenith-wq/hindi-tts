# Hindi TTS

A free Android app that reads Hindi text aloud with your phone's own voices
(male and female) and saves it as a WAV audio file.

Every push to `main` builds the app on GitHub and publishes `HindiTTS.apk`
under **Releases**.
